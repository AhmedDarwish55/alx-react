# 0x06. React Immutable

This project covers the concept of immutability in Javascript

Learning outcomes:

- Immutable objects. Who, what, when, where, and why?
- How to use the Immutable.js library to bring immutability to Javascript
- The differences between List and Map
- How to use Merge, Concat, and Deep Merging
- What a lazy Seq is
