import { Map } from 'immutable';

const getImmutableObject = (object) => Map(object);

module.exports = getImmutableObject;
