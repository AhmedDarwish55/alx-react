// import { fromJS } from 'immutable';
import { fromJS } from './node_modules/immutable/dist/immutable';

const getImmutableObject = (object) => fromJS(object);

export default getImmutableObject;
