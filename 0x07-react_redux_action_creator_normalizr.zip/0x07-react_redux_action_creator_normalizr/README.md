# 0x07. React Redux action creator+normalizr

This project covers the user of Redux action creator and the use of the normalizr library to "flatten" JSON objects

Learning outcomes:
- Normalizr’s purpose and how to use it
- schemas and normalization of nested JSON
- core concepts of Redux
- Redux actions
- Redux action creators
- async actions in Redux
- how to write tests for Redux
