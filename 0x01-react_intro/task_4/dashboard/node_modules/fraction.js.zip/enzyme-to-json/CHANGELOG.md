The changelog is available here: [GitHub releases](https://github.com/adriantoine/enzyme-to-json/releases).
