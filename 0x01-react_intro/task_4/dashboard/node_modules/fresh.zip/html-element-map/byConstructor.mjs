import byConstructor from './byConstructor.js';

export default byConstructor;

export function then(resolve) {
	resolve(byConstructor);
}
