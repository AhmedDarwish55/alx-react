import byTag from './byTag.js';

export default byTag;

export function then(resolve) {
	resolve(byTag);
}
