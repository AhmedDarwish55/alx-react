import byConstructorName from './byConstructorName.js';

export default byConstructorName;

export function then(resolve) {
	resolve(byConstructorName);
}
