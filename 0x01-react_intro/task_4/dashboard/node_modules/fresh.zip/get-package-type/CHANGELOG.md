# Changelog

All notable changes to this project will be documented in this file. See [standard-version](https://github.com/conventional-changelog/standard-version) for commit guidelines.

## 0.1.0 (2020-05-19)


### Features

* Initial implementation ([52863f4](https://github.com/cfware/get-package-type/commit/52863f4b2b7b287fe1adcd97331231a2911312dc))
