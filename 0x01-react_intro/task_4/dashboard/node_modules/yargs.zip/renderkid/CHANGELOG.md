# Renderkid Changelog

## `3.0.0`

* **Breaking change**: Dropped support for Node `<12.x`